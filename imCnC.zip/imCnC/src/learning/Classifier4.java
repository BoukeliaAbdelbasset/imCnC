package learning;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.datavec.api.records.reader.RecordReader;
import org.datavec.api.records.reader.impl.csv.CSVRecordReader;
import org.datavec.api.split.FileSplit;
import org.deeplearning4j.api.storage.StatsStorage;
import org.deeplearning4j.datasets.datavec.RecordReaderDataSetIterator;
import org.deeplearning4j.datasets.datavec.RecordReaderMultiDataSetIterator;
import org.deeplearning4j.datasets.iterator.AsyncMultiDataSetIterator;
import org.deeplearning4j.datasets.iterator.impl.MultiDataSetIteratorAdapter;
import org.deeplearning4j.datasets.test.TestDataSetIterator;
import org.deeplearning4j.eval.Evaluation;
import org.deeplearning4j.evaluation.EvaluationTools;
import org.deeplearning4j.nn.api.OptimizationAlgorithm;
import org.deeplearning4j.nn.conf.ComputationGraphConfiguration;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration;
import org.deeplearning4j.nn.conf.Updater;
import org.deeplearning4j.nn.conf.graph.MergeVertex;
import org.deeplearning4j.nn.conf.inputs.InputType.InputTypeConvolutionalFlat;
import org.deeplearning4j.nn.conf.layers.ConvolutionLayer;
import org.deeplearning4j.nn.conf.layers.DenseLayer;
import org.deeplearning4j.nn.conf.layers.OutputLayer;
import org.deeplearning4j.nn.conf.layers.SubsamplingLayer;
import org.deeplearning4j.nn.graph.ComputationGraph;
import org.deeplearning4j.nn.graph.util.ComputationGraphUtil;
import org.deeplearning4j.nn.weights.WeightInit;
import org.deeplearning4j.ui.api.UIServer;
import org.deeplearning4j.ui.stats.StatsListener;
import org.deeplearning4j.ui.storage.InMemoryStatsStorage;
import org.deeplearning4j.util.ModelSerializer;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.dataset.SplitTestAndTrain;
import org.nd4j.linalg.dataset.api.MultiDataSet;
import org.nd4j.linalg.dataset.api.iterator.DataSetIterator;
import org.nd4j.linalg.dataset.api.iterator.MultiDataSetIterator;
import org.nd4j.linalg.dataset.api.preprocessor.DataNormalization;
import org.nd4j.linalg.dataset.api.preprocessor.MultiDataNormalization;
import org.nd4j.linalg.dataset.api.preprocessor.MultiNormalizerStandardize;
import org.nd4j.linalg.dataset.api.preprocessor.NormalizerStandardize;
import org.nd4j.linalg.factory.Nd4j;
import org.nd4j.linalg.lossfunctions.LossFunctions.LossFunction;

import scala.Int;

public class Classifier4 {

	
	public static ComputationGraph makeComputationGraph() 
	{
		ComputationGraphConfiguration conf = new NeuralNetConfiguration.Builder()
		        .iterations(1) .learningRateScoreBasedDecayRate(0.1)
		        .regularization(true).l2(0.01)
		  .learningRate(0.005)      .weightInit(WeightInit.XAVIER)
		        .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
		        .updater(Updater.NESTEROVS).momentum(0.9)
		        .graphBuilder()
		        .addInputs("sequence", "dnameth","hismeth","hisacy","bh")
		        ///////////////////////////////////////////////////////////////////////////////////////////////////
		        .addLayer("Seq1", new ConvolutionLayer.Builder().activation(Activation.RELU).nIn(1).nOut(800).stride(8,8).padding(200,200).kernelSize(200,4).build(), "sequence")
		        .addLayer("Seq2", new SubsamplingLayer.Builder().stride(10,10).kernelSize(10,10).padding(10,10).build(), "Seq1")
		        .addLayer("Seq3", new ConvolutionLayer.Builder().activation(Activation.RELU).stride(2,2).nIn(800).nOut(800).padding(8,8).kernelSize(8,8).build(), "Seq2")
		        .addLayer("Seq4", new SubsamplingLayer.Builder().padding(4,4).stride(4,4).kernelSize(3,3).build(), "Seq3")
		        .addLayer("d1", new DenseLayer.Builder().activation(Activation.HARDTANH).nOut(800).build(), "Seq4") 
			       
		        /////////////////////////////////////////////////////////////////////////////////
		        .addLayer("MeD1", new ConvolutionLayer.Builder().activation(Activation.RELU).stride(20,20).nIn(1).nOut(4).padding(20,20).kernelSize(4,4).build(), "dnameth")
		        .addLayer("MeD2", new SubsamplingLayer.Builder().stride(10,10).kernelSize(4,4).padding(10,10).build(), "MeD1")
		        .addLayer("MeD3", new ConvolutionLayer.Builder().activation(Activation.RELU).stride(5,5).nIn(4).nOut(4).padding(5,5).kernelSize(4,4).build(), "MeD2")
		        .addLayer("MeD4", new SubsamplingLayer.Builder().padding(4,4).stride(4,4).kernelSize(3,3).build(), "MeD3")
		        .addLayer("d2", new DenseLayer.Builder().activation(Activation.HARDTANH).nOut(4).build(), "MeD4") 
			       
		        /////////////////////////////////////////////////////////////////////////////////////////////////////
		        .addLayer("HM1", new ConvolutionLayer.Builder().activation(Activation.RELU).padding(20,20).stride(20,20).kernelSize(20,3).nIn(1).nOut(60).build(), "hismeth")
		        .addLayer("HM2", new SubsamplingLayer.Builder().kernelSize(10,3).stride(10,10).padding(10,10).build(), "HM1")
		        .addLayer("HM3", new ConvolutionLayer.Builder().activation(Activation.RELU).stride(10,10).kernelSize(10,3).padding(10,10).nIn(60).nOut(60).build(), "HM2")
		        .addLayer("HM4", new SubsamplingLayer.Builder().padding(4,4).stride(4,4).kernelSize(3,3).build(), "HM3")
		        .addLayer("d3", new DenseLayer.Builder().activation(Activation.HARDTANH).nOut(60).build(), "HM4") 
			       
		        ////////////////////////////////////////////////////////////////////////////////////////////////////
		        .addLayer("HA1", new ConvolutionLayer.Builder().activation(Activation.RELU).stride(20,20).kernelSize(18,3).padding(20,20).nIn(1).nOut(54).build(), "hisacy")
		        .addLayer("HA2", new SubsamplingLayer.Builder().kernelSize(9,3).padding(9,9).stride(9,9).build(), "HA1")
		        .addLayer("HA3", new ConvolutionLayer.Builder().activation(Activation.RELU).stride(9,9).kernelSize(9,3).padding(9,9).nIn(54).nOut(54).build(), "HA2")
		        .addLayer("HA4", new SubsamplingLayer.Builder().padding(4,4).stride(4,4).kernelSize(3,3).build(), "HA3")
		        .addLayer("d4", new DenseLayer.Builder().activation(Activation.HARDTANH).nOut(54).build(), "HA4") 
			       
		        //////////////////////////////////////////////////////////////////////////////////////////////////
		        .addLayer("HB1", new ConvolutionLayer.Builder().activation(Activation.RELU).stride(10,10).kernelSize(9,3).nIn(1).nOut(9).padding(10,10).build(), "bh")
		        .addLayer("HB2", new SubsamplingLayer.Builder().stride(3,3).kernelSize(3,3).padding(3,3).build(), "HB1")
		        .addLayer("HB3", new ConvolutionLayer.Builder().activation(Activation.RELU).stride(3,3).kernelSize(3,3).padding(3,3).nIn(9).nOut(9).build(), "HB2")
		        .addLayer("HB4", new SubsamplingLayer.Builder().padding(4,4).stride(4,4).kernelSize(3,3).build(), "HB3")
		        .addLayer("d5", new DenseLayer.Builder().activation(Activation.HARDTANH).nOut(9).build(), "HB4") 
			       
		        ///////////////////////////////////////////////////////////////////////////////////////////////////
		        .addLayer("dense", new DenseLayer.Builder().activation(Activation.HARDTANH).nIn(927).nOut(256).build(), "d1","d2","d3","d4","d5") 
		        .addLayer("dense4", new DenseLayer.Builder().activation(Activation.HARDTANH).nIn(256).nOut(128).build(), "dense") 
		        
		        .addLayer("output", new OutputLayer.Builder().activation(Activation.SOFTMAX).lossFunction(LossFunction.MCXENT).nIn(128).nOut(7).build(), "dense4")
		       .setOutputs("output") 
   .setInputTypes(InputTypeConvolutionalFlat.convolutionalFlat(200, 4,1),InputTypeConvolutionalFlat.convolutionalFlat(2,2,1),
		       		InputTypeConvolutionalFlat.convolutionalFlat(20,3,1),InputTypeConvolutionalFlat.convolutionalFlat(18,3,1),InputTypeConvolutionalFlat.convolutionalFlat(3,3,1))
		    
   .backprop(true).pretrain(true) .build();
		
		ComputationGraph net = new ComputationGraph(conf);
		net.init();
		UIServer uiServer = UIServer.getInstance();

		StatsStorage statsStorage = new InMemoryStatsStorage();         
		uiServer.attach(statsStorage);

		net.setListeners(new StatsListener(statsStorage));
			MultiDataSetIterator data = makeDataSetIterator();
	  		MultiDataSetIterator testData = makeTestData();
System.out.println("aaaa");
for (int i = 0; i < 100; i++) {

	System.out.println("epoch "+i);
	net.fit(data);
 System.out.println(net.score());
}



File locationToSave = new File(System.getProperty("user.home")+"/GraphNonCodingRNAMultiLayerNetwork.zip");     
	try {
		ModelSerializer.writeModel(net, locationToSave,true);
	} catch (IOException e) {

		e.printStackTrace();
	}
	
		return net;
	} 
	
	public static MultiDataSetIterator makeDataSetIterator() {
	 	try {
			  int numLinesToSkip = 0;
		      String delimiter = ",";
		    
		        @SuppressWarnings("deprecation")
				RecordReader sequence = new CSVRecordReader(numLinesToSkip,delimiter);
		      	sequence.initialize(new FileSplit(new File(System.getProperty("user.home")+"/LimitedDataSet/f.csv")));
		        @SuppressWarnings({ "deprecation", "resource" })
				RecordReader dmeth = new CSVRecordReader(numLinesToSkip,delimiter);
		      	dmeth.initialize(new FileSplit(new File(System.getProperty("user.home")+"/LimitedDataSet/DNAMethylationFeaturesN.csv")));
		        @SuppressWarnings({ "deprecation", "resource" })
				RecordReader hm = new CSVRecordReader(numLinesToSkip,delimiter);
		      	hm.initialize(new FileSplit(new File(System.getProperty("user.home")+"/LimitedDataSet/HistoneMethylationN.csv")));
		        @SuppressWarnings("deprecation")
				RecordReader ha = new CSVRecordReader(numLinesToSkip,delimiter);
		      	ha.initialize(new FileSplit(new File(System.getProperty("user.home")+"/LimitedDataSet/HistoneAcyN.csv")));
		      	@SuppressWarnings("deprecation")
				RecordReader hb = new CSVRecordReader(numLinesToSkip,delimiter);
		      	hb.initialize(new FileSplit(new File(System.getProperty("user.home")+"/LimitedDataSet/HistoneBindingFactorN.csv")));
		    	@SuppressWarnings({ "deprecation", "resource" })
				RecordReader labels = new CSVRecordReader(numLinesToSkip,delimiter);
		      	labels.initialize(new FileSplit(new File(System.getProperty("user.home")+"/LimitedDataSet/labels.csv")));
		    
		        ////////////////////////////////////////////////////////////////////////////////
		     	////////////////////////////////////////////////////////////////////////////////
                   RecordReaderMultiDataSetIterator recordmulti = new RecordReaderMultiDataSetIterator.Builder(6)
                		   .addReader("sequence", sequence).addInput("sequence",1,800)
                		   .addReader("dnameth",sequence).addInput("dnameth",801,804)
                		   .addReader("hismeth",sequence).addInput("hismeth",868,927)
                		   .addReader("hisacy", sequence).addInput("hisacy",805,858)
                		   .addReader("bh",sequence).addInput("bh",859,867)
                		   .addReader("output",sequence).addOutputOneHot("output",0,7)
                		   .build();
                   int i = 0;
                  
           
                return   recordmulti;
                
	 	} catch (IOException | InterruptedException e) {
	 	
				// TODO Auto-generated catch block
				e.printStackTrace();return null;
				
			}	
	}
	public  static MultiDataSetIterator makeTestData() {
		DataSetIterator data = null;
		try {
			  int numLinesToSkip = 0;
		      String delimiter = ",";
		    
		        RecordReader sequence = new CSVRecordReader(numLinesToSkip,delimiter);
		      	sequence.initialize(new FileSplit(new File(System.getProperty("user.home")+"/LimitedDataSet/f2.csv")));
		 
		        RecordReaderMultiDataSetIterator recordmulti = new RecordReaderMultiDataSetIterator.Builder(6)
             		   .addReader("sequence", sequence).addInput("sequence",1,800)
             		   .addReader("dnameth",sequence).addInput("dnameth",801,804)
             		   .addReader("hismeth",sequence).addInput("hismeth",868,927)
             		   .addReader("hisacy", sequence).addInput("hisacy",805,858)
             		   .addReader("bh",sequence).addInput("bh",859,867)
             		   .addReader("output",sequence).addOutputOneHot("output",0,7)
             		   .build();
		      //  MultiDataNormalization normalizer = new MultiNormalizerStandardize();
		        return recordmulti;
		}
		catch(Exception e) {e.printStackTrace();}
		return null;
	}
	public static void main(String[]args) 
	{
		
		makeComputationGraph();
	}
}

