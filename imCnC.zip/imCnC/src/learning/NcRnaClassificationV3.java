package learning;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.datavec.api.records.reader.RecordReader;
import org.datavec.api.records.reader.impl.csv.CSVRecordReader;
import org.datavec.api.split.FileSplit;
import org.deeplearning4j.api.storage.StatsStorage;
import org.deeplearning4j.datasets.datavec.RecordReaderDataSetIterator;
import org.deeplearning4j.eval.Evaluation;
import org.deeplearning4j.eval.RegressionEvaluation;
import org.deeplearning4j.nn.api.OptimizationAlgorithm;
import org.deeplearning4j.nn.conf.LearningRatePolicy;
import org.deeplearning4j.nn.conf.MultiLayerConfiguration;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration;
import org.deeplearning4j.nn.conf.Updater;
import org.deeplearning4j.nn.conf.inputs.InputType;
import org.deeplearning4j.nn.conf.layers.BatchNormalization;
import org.deeplearning4j.nn.conf.layers.Convolution1DLayer;
import org.deeplearning4j.nn.conf.layers.ConvolutionLayer;
import org.deeplearning4j.nn.conf.layers.DenseLayer;
import org.deeplearning4j.nn.conf.layers.EmbeddingLayer;
import org.deeplearning4j.nn.conf.layers.GlobalPoolingLayer;
import org.deeplearning4j.nn.conf.layers.LossLayer;
import org.deeplearning4j.nn.conf.layers.OutputLayer;
import org.deeplearning4j.nn.conf.layers.PoolingType;
import org.deeplearning4j.nn.conf.layers.SubsamplingLayer;
import org.deeplearning4j.nn.conf.layers.ZeroPaddingLayer;
import org.deeplearning4j.nn.layers.DropoutLayer;
import org.deeplearning4j.nn.layers.*;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.transferlearning.FineTuneConfiguration;
import org.deeplearning4j.nn.transferlearning.TransferLearning;
import org.deeplearning4j.nn.weights.WeightInit;
import org.deeplearning4j.ui.api.UIServer;
import org.deeplearning4j.ui.stats.StatsListener;
import org.deeplearning4j.ui.storage.InMemoryStatsStorage;
import org.deeplearning4j.util.ModelSerializer;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.dataset.api.iterator.DataSetIterator;
import org.nd4j.linalg.dataset.api.iterator.KFoldIterator;
import org.nd4j.linalg.dataset.api.iterator.TestDataSetIterator;
import org.nd4j.linalg.dataset.api.preprocessor.DataNormalization;
import org.nd4j.linalg.dataset.api.preprocessor.NormalizerStandardize;
import org.nd4j.linalg.lossfunctions.LossFunctions;
import org.nd4j.linalg.lossfunctions.LossFunctions.LossFunction;
public class NcRnaClassificationV3 {
	
 DataSet download(File file){
	  try {
	  int numLinesToSkip = 0;
      String delimiter = " ";
      RecordReader recordReader = new CSVRecordReader(numLinesToSkip,delimiter);
      	recordReader.initialize(new FileSplit(file));
        int labelIndex = 0;     
        int numClasses = -1;     
        int batchSize = 1400;   
        int batchNumTimes =10;
        DataSetIterator iterator = new RecordReaderDataSetIterator(recordReader,batchSize,labelIndex,numClasses,batchNumTimes);
        DataSet trainingData = iterator.next();   
        DataNormalization normalizer = new NormalizerStandardize();
        normalizer.fit(trainingData);          
        normalizer.transform(trainingData);    
        trainingData.shuffle();
   return trainingData;
	} catch (IOException | InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return null;
	}

	} 
  public KFoldIterator CreateKFold(int k,File file)
  {
		  KFoldIterator fold = new KFoldIterator(k, download(file));
			 fold.reset();  
			 return fold;
}
	  
  
  public void Training(File file,int k){
	     long seed = 12345;
	    System.out.println("Build model....");
	  
	    MultiLayerConfiguration conf = new NeuralNetConfiguration.Builder()
	    	     
			        .iterations(1) 
			        .regularization(true).l2(0.005)
			  .learningRate(0.005)      .weightInit(WeightInit.XAVIER)
			        .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
			        .updater(Updater.NESTEROVS).momentum(0.9)
			 
	        .list()
	        .layer(0, new ConvolutionLayer.Builder().nIn(1).stride(10,10).kernelSize(20,3).padding(20,20).nOut(1).activation(Activation.RELU).build())
	        .layer(1, new SubsamplingLayer.Builder(PoolingType.MAX).kernelSize(10,3).stride(3,3).padding(10,10).build())
	        .layer(2, new DenseLayer.Builder().activation(Activation.HARDTANH).nOut(512).build())   
		    .layer(3, new DenseLayer.Builder().activation(Activation.HARDTANH).nOut(256).build())   
		    .layer(4, new DenseLayer.Builder().activation(Activation.HARDTANH).nOut(128).build())   
		 
		    .layer(5,new OutputLayer.Builder().lossFunction(LossFunction.MEAN_ABSOLUTE_ERROR).activation(Activation.IDENTITY).nOut(-1).nIn(128).build())
	       .setInputType(InputType.convolutionalFlat(43,1,1)) 
	        .backprop(true).pretrain(true).build();

       	  MultiLayerNetwork net = new MultiLayerNetwork(conf);
            net.init();
             	    
    	    KFoldIterator fold = CreateKFold(k, file);
             double accuracy = 0;
             double specificity = 0;
             double precision = 0;
             double sensitivity = 0;
             boolean b = true;
             while(b)
             {
                       	 fold.reset();
            	 accuracy = 0;
                specificity = 0;
                 precision = 0;
                 	 
            	
                 while(fold.hasNext())
                 {
                	DataSet train = fold.next();
                	
                	 net.fit(train);
                	 RegressionEvaluation eval = net.evaluateRegression(new TestDataSetIterator(fold.testFold()));
                	 
                 INDArray out= net.output(fold.testFold().getFeatureMatrix());	
                 eval.eval(fold.testFold().getLabels(), out);
                	System.out.println(eval.stats());
                	
                 } 
                  
             }
        

        
  }
       	
            		
          
        
 
  public static void main(String[]args)
  {
	 
	 new NcRnaClassificationV3().Training(new File(System.getProperty("user.home")+"/output.csv"),5);
	 
  } 
 
  
}
