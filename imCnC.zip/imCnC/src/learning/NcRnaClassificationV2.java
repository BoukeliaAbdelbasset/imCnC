package learning;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.datavec.api.records.reader.RecordReader;
import org.datavec.api.records.reader.impl.csv.CSVRecordReader;
import org.datavec.api.split.FileSplit;
import org.deeplearning4j.api.storage.StatsStorage;
import org.deeplearning4j.datasets.datavec.RecordReaderDataSetIterator;
import org.deeplearning4j.eval.Evaluation;
import org.deeplearning4j.nn.api.OptimizationAlgorithm;
import org.deeplearning4j.nn.conf.LearningRatePolicy;
import org.deeplearning4j.nn.conf.MultiLayerConfiguration;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration;
import org.deeplearning4j.nn.conf.Updater;
import org.deeplearning4j.nn.conf.inputs.InputType;
import org.deeplearning4j.nn.conf.layers.BatchNormalization;
import org.deeplearning4j.nn.conf.layers.Convolution1DLayer;
import org.deeplearning4j.nn.conf.layers.ConvolutionLayer;
import org.deeplearning4j.nn.conf.layers.DenseLayer;
import org.deeplearning4j.nn.conf.layers.EmbeddingLayer;
import org.deeplearning4j.nn.conf.layers.GlobalPoolingLayer;
import org.deeplearning4j.nn.conf.layers.LossLayer;
import org.deeplearning4j.nn.conf.layers.OutputLayer;
import org.deeplearning4j.nn.conf.layers.PoolingType;
import org.deeplearning4j.nn.conf.layers.SubsamplingLayer;
import org.deeplearning4j.nn.conf.layers.ZeroPaddingLayer;
import org.deeplearning4j.nn.layers.DropoutLayer;
import org.deeplearning4j.nn.layers.*;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.transferlearning.FineTuneConfiguration;
import org.deeplearning4j.nn.transferlearning.TransferLearning;
import org.deeplearning4j.nn.weights.WeightInit;
import org.deeplearning4j.ui.api.UIServer;
import org.deeplearning4j.ui.stats.StatsListener;
import org.deeplearning4j.ui.storage.InMemoryStatsStorage;
import org.deeplearning4j.util.ModelSerializer;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.dataset.api.iterator.DataSetIterator;
import org.nd4j.linalg.dataset.api.iterator.KFoldIterator;
import org.nd4j.linalg.dataset.api.iterator.TestDataSetIterator;
import org.nd4j.linalg.dataset.api.preprocessor.DataNormalization;
import org.nd4j.linalg.dataset.api.preprocessor.NormalizerStandardize;
import org.nd4j.linalg.lossfunctions.LossFunctions;
import org.nd4j.linalg.lossfunctions.LossFunctions.LossFunction;
public class NcRnaClassificationV2 {
	
 DataSet download(File file){
	  try {
	  int numLinesToSkip = 0;
      String delimiter = ",";
      RecordReader recordReader = new CSVRecordReader(numLinesToSkip,delimiter);
      	recordReader.initialize(new FileSplit(file));
        int labelIndex = 0;     
        int numClasses = 7;     
        int batchSize = 3600;   
        int batchNumTimes =10;
        DataSetIterator iterator = new RecordReaderDataSetIterator(recordReader,batchSize,labelIndex,numClasses,batchNumTimes);
        DataSet trainingData = iterator.next();   
        DataNormalization normalizer = new NormalizerStandardize();
        normalizer.fit(trainingData);          
        normalizer.transform(trainingData);    
        trainingData.shuffle();
   return trainingData;
	} catch (IOException | InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return null;
	}

	} 
  public KFoldIterator CreateKFold(int k,File file)
  {
		  KFoldIterator fold = new KFoldIterator(k, download(file));
			 fold.reset();  
			 return fold;
}
	  
  
  public void Training(File file,int k){
	     long seed = 12345;
	    System.out.println("Build model....");
	  
	    MultiLayerConfiguration conf = new NeuralNetConfiguration.Builder()
	    	     
			        .iterations(1) 
			        .regularization(true).l2(0.005)
			  .learningRate(0.005)      .weightInit(WeightInit.XAVIER)
			        .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
			        .updater(Updater.NESTEROVS).momentum(0.9)
			 
	        .list()
	        .layer(0, new ConvolutionLayer.Builder().nIn(1).stride(10,10).kernelSize(20,3).padding(20,20).nOut(1).activation(Activation.RELU).build())
	        .layer(1, new SubsamplingLayer.Builder(PoolingType.MAX).kernelSize(10,3).stride(3,3).padding(10,10).build())
	        .layer(2, new ConvolutionLayer.Builder().nIn(1).stride(4,4).kernelSize(10,3).padding(10,10).nOut(1).activation(Activation.RELU).build())
	        .layer(3, new SubsamplingLayer.Builder(PoolingType.MAX).kernelSize(5,3).stride(3,3).padding(5,5).build())
	        .layer(4, new ConvolutionLayer.Builder().nIn(1).stride(2,2).kernelSize(5,3).padding(10,3).nOut(1).activation(Activation.RELU).build())
	        .layer(5, new SubsamplingLayer.Builder(PoolingType.MAX).kernelSize(3,3).stride(3,3).padding(10,10).build())
		    .layer(6, new ConvolutionLayer.Builder().nIn(1).stride(2,2).kernelSize(1,3).padding(3,3).nOut(1).activation(Activation.RELU).build())
	        .layer(7, new SubsamplingLayer.Builder(PoolingType.MAX).kernelSize(3,3).stride(2,2).padding(3,3).build())
	        .layer(8, new ConvolutionLayer.Builder().nIn(1).stride(3,3).kernelSize(3,3).padding(3,3).nOut(1).activation(Activation.RELU).build())
	        .layer(9, new SubsamplingLayer.Builder(PoolingType.MAX).kernelSize(3,3).stride(3,3).padding(3,3).build())
		    .layer(10, new DenseLayer.Builder().activation(Activation.HARDTANH).nOut(2048).build())
		    .layer(11, new DenseLayer.Builder().activation(Activation.HARDTANH).nOut(1024).build())
		    .layer(12, new DenseLayer.Builder().activation(Activation.HARDTANH).nOut(512).build())   
		    .layer(13, new DenseLayer.Builder().activation(Activation.HARDTANH).nOut(256).build())   
		    .layer(14, new DenseLayer.Builder().activation(Activation.HARDTANH).nOut(128).build())   
		 
		    .layer(15,new OutputLayer.Builder().lossFunction(LossFunction.MCXENT).activation(Activation.SOFTMAX).nOut(7).nIn(128).build())
	       .setInputType(InputType.convolutionalFlat(309,3,1)) 
	        .backprop(true).pretrain(true).build();

       	  MultiLayerNetwork net = new MultiLayerNetwork(conf);
            net.init();
             	    
    	    KFoldIterator fold = CreateKFold(k, file);
             double accuracy = 0;
             double specificity = 0;
             double precision = 0;
             double sensitivity = 0;
             boolean b = true;
             while(b)
             {
                       	 fold.reset();
            	 accuracy = 0;
                specificity = 0;
                 precision = 0;
                 	 
            	
                 while(fold.hasNext())
                 {
                	DataSet train = fold.next();
                	
                	 net.fit(train);
                	 Evaluation eval = new Evaluation();
                	 
                 INDArray out= net.output(fold.testFold().getFeatureMatrix());	
                 eval.eval(fold.testFold().getLabels(), out);
                	System.out.println(eval.stats());
                	
              	    
                 accuracy += eval.accuracy();
              precision += eval.precision();
            sensitivity+= eval.falsePositiveRate();
            specificity+= eval.falseNegativeRate();
          	 System.out.println(eval.stats());
                 }
                 System.out.println("Accuracy Moyenne : "+accuracy/5+"   Precision Moyenne  "+precision/5+"  Sensitivity Moyenne  "+sensitivity/5 +"  Specificity "+ specificity/5);
                if(accuracy/5 > 0.992)
                {
              	  File locationToSave = new File(System.getProperty("user.home")+"/NonCodingRNAMultiLayerNetwork.zip");     
		 		  boolean saveUpdater = true;                                      
		 		  try {
					ModelSerializer.writeModel(net, locationToSave, saveUpdater);
					net.getDefaultConfiguration().toJson();
					break;
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 		 	
                } 
                  
             }
        

        
  }
       	
            		
          
        
 
  public static void main(String[]args)
  {
	 
	 new NcRnaClassificationV2().Training(new File(System.getProperty("user.home")+"/LimitedDataSet/f.csv"),5);
	 
  } 
 
  
}
