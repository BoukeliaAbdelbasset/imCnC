package prediction;

public class NcRNATypePrediction {

}
