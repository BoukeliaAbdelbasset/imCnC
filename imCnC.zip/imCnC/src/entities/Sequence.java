package entities;

public class Sequence {
public String identifier;
public String sequence;
public Position position;
public String type;
public Sequence(){}
public Sequence(String identifier,String sequence)
{this.identifier = identifier;
this.sequence = sequence;
	}
public Sequence(String identifier,String sequence,Position position,String type)
{this.identifier = identifier;
this.sequence = sequence;
this.position = position;
this.type = type;
	}
public Sequence(String str) {
	identifier = str.split(",")[1]; 
	sequence = str.split(",")[7];
	position = new Position(Integer.parseInt(str.split(",")[3]),Integer.parseInt(str.split(",")[4]),str.split(",")[2]);
	type = str.split(",")[0];
	
}

public String toString(){
	
	return identifier+System.lineSeparator()+sequence+System.lineSeparator()+type+System.lineSeparator()+position;
}


}
