package entities;

public class MethFeaturesM {
public double features[][]= new double[2][2];
public MethFeaturesM() {
	for(int i=0; i < features.length;i++){
		 for(int j =0; j < features[i].length;j++) 
		 {
			 features[i][j]= 0;
		 }
	 }
}
public MethFeaturesM(MethFeatures feature) 
{
	features[0][0] = feature.nearest;
	features[0][1] = feature.farest;
	features[1][0] = feature.numberOfFeatures;
	features[1][1]= feature.numberOfMethIn;
	}
public String toString() {
	return features[0][0]+","+features[0][1]+","+features[1][0]+","+features[1][1];
}
}
