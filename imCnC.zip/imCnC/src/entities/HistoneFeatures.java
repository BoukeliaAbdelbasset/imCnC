package entities;

public class HistoneFeatures {
public double numberOfFeatures;
public double nearest;
public double farest;

public HistoneFeatures(){}
public HistoneFeatures(double numberOfFeatures, double nearest,double farest)
{
	this.numberOfFeatures = numberOfFeatures;
	this.nearest = nearest;
	this.farest = farest;
}
public double getNumberOfFeatures() {
	return numberOfFeatures;
}
public void setNumberOfFeatures(double numberOfFeatures) {
	this.numberOfFeatures = numberOfFeatures;
}
public double getNearest() {
	return nearest;
}
public void setNearest(double nearest) {
	this.nearest = nearest;
}
public double getFarest() {
	return farest;
}
public void setFarest(double farest) {
	this.farest = farest;
}
public String toString(){
	return numberOfFeatures+","+nearest+","+farest+",";
}

}
