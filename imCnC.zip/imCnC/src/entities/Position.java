package entities;

public class Position {
int begin;
int end;
String chromosome;
public Position(){}
public Position(String position)
{
	position = position.replaceAll("    ", "	");
	try{
		chromosome= position.split("	")[0];
		begin = Integer.parseInt(position.split("	")[1]);
		end = Integer.parseInt(position.split("	")[2]);	}
	catch(Exception e){}
}
public void getPositionMeth(String position)
{
	position = position.replaceAll("    ", "	");
	try{
		chromosome= position.split("	")[0];
		begin = Integer.parseInt(position.split("	")[1]);
		end = Integer.parseInt(position.split("	")[1]);	}
	catch(Exception e){}
   
	}
public Position(int begin,int end,String chromosome)
{
	this.begin = begin;
	this.end = end;
	this.chromosome = chromosome;
	}
public int getBegin() {
	return begin;
}
public void setBegin(int begin) {
	this.begin = begin;
}
public int getEnd() {
	return end;
}
public void setEnd(int end) {
	this.end = end;
}
public String getChromosome(){return chromosome;}
public void setChromosome(String chromosome){ this.chromosome = chromosome;}

public String toString()
{
	return chromosome+"  "+begin+"  "+end;}}
