package entities;

public class SeqFeature {
double[][] features = new double[200][4] ;

public SeqFeature(){
 for(int i=0; i < features.length;i++){
	 for(int j =0; j < features[i].length;j++) 
	 {
		 features[i][j]= 0;
	 }
 }
 
}
public SeqFeature(Sequence seq)
{
 new SeqFeature();
 int i = 0;
 for(Character c:seq.sequence.toCharArray()) 
 {
	 System.out.println(seq.sequence.length());
	 switch (c) {
	case 'A':  features[i][0]= 1; break;
	case 'a':  features[i][0]= 1; 
	break;
	case 'C': features[i][1] = 1;  break;
	case 'c': features[i][1] = 1; 
	break;
	case 'G': features[i][2]=1; break;
	case 'g': features[i][2]=1;
	break;
	case 'T':features [i][3]=1;	break;
	case 't':features [i][3]=1;	
      break;
	case 'U':features [i][3]=1;	break;
	case 'u':features [i][3]=1;	
      break;
	}
	 i++;
	 
 }
 
}
public String toString() {
	String featureVec = "";
		   for(int i=0; i < features.length;i++){
			 for(int j =0; j < features[i].length;j++) 
			 {
				 if(i == features.length - 1 && j == features[i].length-1 ) {
					  featureVec += features[i][j];
						
				 }
				 else {
				  featureVec += features[i][j]+",";}
			
				 
			 }
		 }
	    return featureVec;
		}
}
