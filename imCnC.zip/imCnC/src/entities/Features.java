package entities;

import java.util.ArrayList;

public class Features {
	public SeqFeature seqFeatures;
	public ArrayList<HistoneFeatures> epiGFeatures;
	public MethFeatures methFeatures;
	public Features(){
		epiGFeatures = new ArrayList<>();
		seqFeatures = new SeqFeature();
		methFeatures = new MethFeatures();
	}
	public Features(SeqFeature seqFeatures,ArrayList<HistoneFeatures> histoneList, MethFeatures methList)
	{
		this.seqFeatures = seqFeatures;
		this.epiGFeatures = histoneList;
		this.methFeatures = methList;
	}
	public SeqFeature getSeqFeatures() {
		return seqFeatures;
	}
	public void setSeqFeatures(SeqFeature seqFeatures) {
		this.seqFeatures = seqFeatures;
	}
	public ArrayList<HistoneFeatures> getEpiGFeatures() {
		return epiGFeatures;
	}
	public void setEpiGFeatures(ArrayList<HistoneFeatures> epiGFeatures) {
		this.epiGFeatures = epiGFeatures;
	}
	public String toString(){
		String histoneFeatures =	epiGFeatures.toString().substring(1, epiGFeatures.toString().length()-2);
			
	return seqFeatures+histoneFeatures+","+methFeatures.toString();
	}
}
