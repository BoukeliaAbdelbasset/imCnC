package entities;

public class MethFeatures extends HistoneFeatures {
    public double numberOfMethIn;
	public MethFeatures() {
	}

	public MethFeatures(double numberOfFeatures, double nearest, double farest,double numberOfMethIn) {
		super(numberOfFeatures, nearest, farest);
		this.numberOfMethIn = numberOfMethIn;
	}
	public void setNumberOfMethIn(double numberMeth){
		numberOfMethIn = numberMeth;
	}
	public double getNumberOfMethIn(){return numberOfMethIn;}
    public String toString(){
    	return numberOfFeatures+","+nearest+","+farest+","+numberOfMethIn;
    }
}
