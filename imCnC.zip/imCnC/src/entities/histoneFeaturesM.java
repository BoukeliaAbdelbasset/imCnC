package entities;

import java.util.ArrayList;

public class histoneFeaturesM {
public double[][] features = new double[1][3];
public histoneFeaturesM() {
	
	for(int i=0; i < features.length;i++){
		 for(int j =0; j < features[i].length;j++) 
		 {
			 features[i][j]= 0;
		 }
	 }
	 
}
public histoneFeaturesM(ArrayList<HistoneFeatures> list)
{
	int i = 0;
	for(HistoneFeatures f:list) 
	{
		features[i][0] = f.nearest;
		features[i][1] = f.farest;
		features[i][2]= f.numberOfFeatures;
		i++;
	}
}
public  String toString() 
{ 
	String featureVec = "";
   for(int i=0; i < features.length;i++){
		 for(int j =0; j < features[i].length;j++) 
		 {
			 if(i == features.length-1 && j == features[i].length-1 ) {
				  featureVec += features[i][j];
						 
			 }else {
			  featureVec += features[i][j]+",";}
			 
		 }
	 }
    return featureVec;
	}
}