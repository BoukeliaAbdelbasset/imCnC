package utils;

public class GenerateLabel {
public static int getLabelFrom(String str) 
{ int i = 0;
if(str.contains("tR")|| str.contains("TR")) {i = 0;}
else {
	
	if(str.contains("piR")) { i = 1;}
	else 
	{if(str.contains("mi")) {i = 2;}
	else{
		if(str.contains("sno")) {i=3;}
		else {
			if(str.contains("rR")) {i = 4;}
			else {
				if (str.contains("snR")) {
					i = 5;
				}
				else {
					if(str.contains("scR")){}
					i = 6;
				}
			}		}
		}
	
	}
}
return i;
}
}