package utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Comparator;

import entities.HistoneFeatures;
import entities.Position;
import entities.Sequence;
import entities.histoneFeaturesM;

public class HistoneFeaturesBuilder {

	public static void generateHistoneFeaturesE(ArrayList<Sequence> listSeq,ArrayList<Position> listModifications,String path)
	{
		
		File file = new File(path); 
		try {
		BufferedWriter buff = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
		for(Sequence seq:listSeq) 
		{
			System.out.println(seq.identifier);
			if(!(seq.sequence.length()>200)) {
			ArrayList<HistoneFeatures> histoneFeatures = new ArrayList<>();
			
				ArrayList<Integer> map = new ArrayList<>();
				for(Position position:listModifications) {
					 if(seq.position.getChromosome().contains(position.getChromosome()))
					   {
						  
						   if((seq.position.getEnd() - position.getBegin()) <1500  && seq.position.getEnd() - position.getBegin() >=0)
						   {
							   if(seq.position.getEnd()- position.getBegin()== 0  ){
								   map.add(1);
							   }else{
							   
							   map.add(new Integer((seq.position.getEnd() - position.getBegin())));}
						   }
						   else{
						   if( position.getEnd() - seq.position.getBegin() < 1500 && position.getEnd() - seq.position.getBegin() > 0 ){
							   
							   if(position.getEnd()- seq.position.getBegin()== 0  ){
							   map.add(1);
							   }
							   else{
							   map.add(new Integer( position.getEnd() - seq.position.getBegin()));}
							
						   }}
						   
					   }
				   }
				   map.sort(Comparator.naturalOrder());
				   int i = 0;
				   int j = 0;
				   if(map.size()!=0){
					   i = map.get(0);
					   j = map.get(map.size()-1);
				   }
				   map.trimToSize();
				   HistoneFeatures histone = new HistoneFeatures(map.size(),i,j);
				   
			       histoneFeatures.add(histone);
					
					
				
			histoneFeatures.trimToSize();
			histoneFeaturesM histoneM = new histoneFeaturesM(histoneFeatures);
				buff.write(GenerateLabel.getLabelFrom(seq.type)+","+histoneM.toString());
				buff.write(System.lineSeparator());
						}
			
			

				}
		buff.flush();
		buff.close();}
		catch(Exception e) {e.printStackTrace();}}
			
		


public static void generateHistoneFeatures(ArrayList<Sequence> listSeq,ArrayList<ArrayList<Position>> listModifications,String path)
{
	
	File file = new File(path+"/HistoneMethylationFeatures.csv"); 
	try {
	BufferedWriter buff = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
	for(Sequence seq:listSeq) 
	{
		System.out.println(seq.identifier);
		if(!(seq.sequence.length()>200)) {
		ArrayList<HistoneFeatures> histoneFeatures = new ArrayList<>();
		
		for (ArrayList<Position> list:listModifications) 
		{
			ArrayList<Integer> map = new ArrayList<>();
			for(Position position:list) {
				 if(seq.position.getChromosome().contains(position.getChromosome()))
				   {
					  
					   if((seq.position.getEnd() - position.getBegin()) <1500  && seq.position.getEnd() - position.getBegin() >=0)
					   {
						   if(seq.position.getEnd()- position.getBegin()== 0  ){
							   map.add(1);
						   }else{
						   
						   map.add(new Integer((seq.position.getEnd() - position.getBegin())));}
					   }
					   else{
					   if( position.getEnd() - seq.position.getBegin() < 1500 && position.getEnd() - seq.position.getBegin() > 0 ){
						   
						   if(position.getEnd()- seq.position.getBegin()== 0  ){
						   map.add(1);
						   }
						   else{
						   map.add(new Integer( position.getEnd() - seq.position.getBegin()));}
						
					   }}
					   
				   }
			   }
			   map.sort(Comparator.naturalOrder());
			   int i = 0;
			   int j = 0;
			   if(map.size()!=0){
				   i = map.get(0);
				   j = map.get(map.size()-1);
			   }
			   map.trimToSize();
			   HistoneFeatures histone = new HistoneFeatures(map.size(),i,j);
			   
		       histoneFeatures.add(histone);
				
				
			}
		histoneFeatures.trimToSize();
		histoneFeaturesM histoneM = new histoneFeaturesM(histoneFeatures);
			buff.write(GenerateLabel.getLabelFrom(seq.type)+","+histoneM.toString());
			buff.write(System.lineSeparator());
					}
		
		

			}
	buff.flush();
	buff.close();}
	catch(Exception e) {e.printStackTrace();}}
		}
	
	


