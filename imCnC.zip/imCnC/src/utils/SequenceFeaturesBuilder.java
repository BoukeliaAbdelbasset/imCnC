package utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import entities.SeqFeature;
import entities.Sequence;

public class SequenceFeaturesBuilder {
public static void generateFeaturesFile(String path,ArrayList<Sequence> listSeq) 
{
	File file = new File(path+"/SeqFeatures.csv"); 
	try{
		BufferedWriter buff = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
		for(Sequence seq:listSeq) 
		{
			buff.write(GenerateLabel.getLabelFrom(seq.type)+","+new SeqFeature(seq).toString());
			buff.write(System.lineSeparator());
			
		}
		buff.flush();
		buff.close();
		
	}
	catch(Exception e) {e.printStackTrace();}}
public static void main(String[] args) 
{
	generateFeaturesFile(System.getProperty("user.home")+"/generatedData/",SequencesBuilder.getSequences(new File(System.getProperty("user.home")+"/SequenceTable.csv")));}
}
