package utils;

import java.io.*;
import java.util.ArrayList;
import entities.Sequence;
import learning.Classifier;
public class SequencesBuilder {
public static ArrayList<Sequence> getSequences(File file){
	ArrayList<Sequence> listSeqs = new ArrayList<>() ;
	try {
		BufferedReader buff = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
		String str ="";
		while((str=buff.readLine())!=null) 
		{
			if(! (new Sequence(str).sequence.length() > 200)) {
			listSeqs.add(new Sequence(str));}
		}
		
		buff.close();
		
	}
	catch(Exception e) {e.printStackTrace();}
	return listSeqs;
}
public static void main(String []args) {
	/*new File(System.getProperty("user.home")+"/generatedData/").mkdirs();
//FeaturesVectorConstruction.getHistonesFeatures( getSequences(new File(System.getProperty("user.home")+"/SequenceTable.csv")),System.getProperty("user.home")+"/generatedData/");
 // MethFeaturesBuilder.generateDNAMethylationFeatures(getSequences(new File(System.getProperty("user.home")+"/SequenceTable.csv")),ModificationsToMemory.getDNAMethylations(),System.getProperty("user.home")+"/generatedData/");
File file = new File(System.getProperty("user.home")+"/datas/DeepNcRna/DataDeep/HistoneModification/");
for(File f:file.listFiles()) 
{
	HistoneFeaturesBuilder.generateHistoneFeaturesE( getSequences(new File(System.getProperty("user.home")+"/SequenceTable.csv")),ModificationsToMemory.getHistoneModificationsByOne(f),System.getProperty("user.home")+"/generatedData/"+f.getName()+".csv");}

} */
Classifier.makeComputationGraph();
}
}

