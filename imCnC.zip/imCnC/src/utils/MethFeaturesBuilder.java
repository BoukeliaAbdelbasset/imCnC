package utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Comparator;
import entities.MethFeatures;
import entities.MethFeaturesM;
import entities.Position;
import entities.Sequence;

public class MethFeaturesBuilder {
	public static void generateDNAMethylationFeatures(ArrayList<Sequence> listSeq,ArrayList<Position> listModifications,String path)
	{

		File file = new File(path+"/DNAMethylationFeatures.csv"); 
		try {
		BufferedWriter buff = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
		for(Sequence seq:listSeq) 
		{
			ArrayList<Integer> map = new ArrayList<>();
			int methIn = 0;
			
			System.out.println(seq.identifier);
			if(!(seq.sequence.length()>200)) {
						
			for (Position p:listModifications) 
			{
					 if(seq.position.getChromosome().equals(p.getChromosome()))
					   {
						  if((p.getEnd() - seq.position.getBegin()) <1500  && p.getEnd() - seq.position.getBegin() >=0)
						   {
							 	   map.add(new Integer((p.getEnd() - seq.position.getBegin())));}
						   
						   else{
							   if( seq.position.getEnd() - p.getBegin() < 1500 && seq.position.getEnd() - p.getBegin() >= 0 ){
								 
								   map.add(new Integer( seq.position.getEnd() - p.getBegin()));}
								
							   }
						   if( p.getBegin() >= seq.position.getBegin() && p.getEnd() <= seq.position.getEnd())
						   {
							   
							   methIn++;
						   
						   }
						   
					   }
				   
				
				   }
		
						}
			 map.sort(Comparator.naturalOrder());
			   int i = 0;
			   int j = 0;
			   if(map.size()!=0) {
				   i = map.get(0);
				   j = map.get(map.size()-1);}
					   MethFeatures features = new MethFeatures(map.size(),i,j,methIn);
					      
						
						
						MethFeaturesM methFeaturesM = new MethFeaturesM(features);
						buff.write(GenerateLabel.getLabelFrom(seq.type)+","+methFeaturesM.toString());
						buff.write(System.lineSeparator());}
		  
		
		}
		catch(Exception e) {e.printStackTrace();}
		
	
}}
