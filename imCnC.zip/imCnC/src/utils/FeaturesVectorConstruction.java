package utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Comparator;

import entities.Features;
import entities.HistoneFeatures;
import entities.MethFeatures;
import entities.Position;
import entities.SeqFeature;
import entities.Sequence;
import entities.histoneFeaturesM;

public class FeaturesVectorConstruction {

	public static void  getHistonesFeatures(ArrayList<Sequence> listSeq,String path){
		File file = new File(path+"/HistoneMethylationFeatures.csv"); 
		File file2 = new File(System.getProperty("user.home")+"/datas/DeepNcRna/DataDeep/HistoneModification/");
		
		try {
		BufferedWriter buff = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
		for(Sequence seq:listSeq) 
		{
			System.out.println(seq.identifier+"-"+seq.type);
			ArrayList<HistoneFeatures> histoneFeatures = new ArrayList<>();
			
			for(File f:file2.listFiles())
			{		ArrayList<Integer> map = new ArrayList<>();
				try{
				   FileInputStream reader = new FileInputStream(f);
				   BufferedReader buff2 = new BufferedReader(new InputStreamReader(reader));
				   String str ="";
				   while((str =buff2.readLine()) != null){
					   if(str.contains(seq.position.getChromosome()))
					   {
						   Position position = new Position(str);
						   if((seq.position.getEnd() - position.getBegin()) <1000  && seq.position.getEnd() - position.getBegin() >=0)
						   {
							   if(seq.position.getEnd()- position.getBegin()== 0  ){
								   map.add(1);
							   }else{
							   
							   map.add(new Integer((seq.position.getEnd() - position.getBegin())));}
						   }
						   else{
						   if( position.getEnd() - seq.position.getBegin() < 1000 && position.getEnd() - seq.position.getBegin() > 0 ){
							   if(position.getEnd()- seq.position.getBegin()== 0  ){
							   map.add(1);
							   }
							   else{
							   map.add(new Integer( position.getEnd() - seq.position.getBegin()));}
							
						   }}
						   
					   }
				   }}
				catch(Exception e){
					e.printStackTrace();}
				   map.sort(Comparator.naturalOrder());
				   int i = 0;
				   int j = 0;
				   if(map.size()!=0){
					   i = map.get(0);
					   j = map.get(map.size()-1);
				   }
				   HistoneFeatures histone = new HistoneFeatures(map.size(),i,j);
			       histoneFeatures.add(histone);
			     		}	histoneFeatures.trimToSize();
			histoneFeaturesM histoneM = new histoneFeaturesM(histoneFeatures);
				buff.write(GenerateLabel.getLabelFrom(seq.type)+","+histoneM.toString());
				buff.write(System.lineSeparator());
						}
			
			

				
		buff.flush();
		buff.close();}
		catch(Exception e) {e.printStackTrace();}}
	public static void  getAcyHistonesFeatures(ArrayList<Sequence> listSeq,String path){
		File file = new File(path+"/HistoneAcylFeatures.csv"); 
		File file2 = new File(System.getProperty("user.home")+"/datas/DeepNcRna/DataDeep/DataAcy/");
		
		try {
		BufferedWriter buff = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
		for(Sequence seq:listSeq) 
		{
			System.out.println(seq.identifier+"-"+seq.type);
			ArrayList<HistoneFeatures> histoneFeatures = new ArrayList<>();
			
			for(File f:file2.listFiles())
			{		ArrayList<Integer> map = new ArrayList<>();
				try{
				   FileInputStream reader = new FileInputStream(f);
				   BufferedReader buff2 = new BufferedReader(new InputStreamReader(reader));
				   String str ="";
				   while((str =buff2.readLine()) != null){
					   if(str.contains(seq.position.getChromosome()))
					   {
						   Position position = new Position(str);
						   if((seq.position.getEnd() - position.getBegin()) <1000  && seq.position.getEnd() - position.getBegin() >=0)
						   {
							   if(seq.position.getEnd()- position.getBegin()== 0  ){
								   map.add(1);
							   }else{
							   
							   map.add(new Integer((seq.position.getEnd() - position.getBegin())));}
						   }
						   else{
						   if( position.getEnd() - seq.position.getBegin() < 1000 && position.getEnd() - seq.position.getBegin() > 0 ){
							   if(position.getEnd()- seq.position.getBegin()== 0  ){
							   map.add(1);
							   }
							   else{
							   map.add(new Integer( position.getEnd() - seq.position.getBegin()));}
							
						   }}
						   
					   }
				   }}
				catch(Exception e){
					e.printStackTrace();}
				   map.sort(Comparator.naturalOrder());
				   int i = 0;
				   int j = 0;
				   if(map.size()!=0){
					   i = map.get(0);
					   j = map.get(map.size()-1);
				   }
				   HistoneFeatures histone = new HistoneFeatures(map.size(),i,j);
			       histoneFeatures.add(histone);
			     		}	histoneFeatures.trimToSize();
			histoneFeaturesM histoneM = new histoneFeaturesM(histoneFeatures);
				buff.write(GenerateLabel.getLabelFrom(seq.type)+","+histoneM.toString());
				buff.write(System.lineSeparator());
						}
			
			

				
		buff.flush();
		buff.close();}
		catch(Exception e) {e.printStackTrace();}}
	
	
	public static void main(String []args) {
		new File(System.getProperty("user.home")+"/generatedData/").mkdirs();
	FeaturesVectorConstruction.getAcyHistonesFeatures( SequencesBuilder.getSequences(new File(System.getProperty("user.home")+"/SequenceTable.csv")),System.getProperty("user.home")+"/generatedData/");
	 // MethFeaturesBuilder.generateDNAMethylationFeatures(getSequences(new File(System.getProperty("user.home")+"/SequenceTable.csv")),ModificationsToMemory.getDNAMethylations(),System.getProperty("user.home")+"/generatedData/");
	}
}
