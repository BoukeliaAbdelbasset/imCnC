package utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import entities.Position;

public class ModificationsToMemory {
	public static ArrayList<Position> getHistoneModificationsByOne(File file){
		ArrayList<Position> listModification = new ArrayList<>();
		
			try {
			BufferedReader buff = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			String str = "";
			while((str=buff.readLine())!=null)
			{
				listModification.add(new Position(str));
			}
			
			buff.close();
			}
		catch(Exception e) {};
		listModification.trimToSize();
	 	
		return listModification;
	}

	public static ArrayList<ArrayList<Position>> getHistoneModifications(){
		ArrayList<ArrayList<Position>> listModification = new ArrayList<>();
		
		File file = new File(System.getProperty("user.home")+"/datas/DeepNcRna/DataDeep/HistoneModification/");
		for(File f:file.listFiles()) 
		{
			System.out.println(f.getName());
			ArrayList<Position> listPosition = new ArrayList<>();
			try {
			BufferedReader buff = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
			String str = "";
			while((str=buff.readLine())!=null)
			{
				listPosition.add(new Position(str));
			}
			
			buff.close();
			}
		catch(Exception e) {};
		listModification.trimToSize();
		  listModification.add(listPosition);
		}
	  listModification.trimToSize();
		
		return listModification;
	}
	public static ArrayList<Position> getDNAMethylations(){
		ArrayList<Position> listMethylation = new ArrayList<>();
		File file = new File(System.getProperty("user.home")+"/datas/DeepNcRna/DataDeep/DNA Methylation/Control3_AC");
		try {
			BufferedReader buff = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			String str = "";
			while((str=buff.readLine())!=null)
			{
			  Position position = new Position();
			  position.getPositionMeth(str);
				listMethylation.add(position);
			}
			buff.close();
			}
		catch(Exception e) {};
		
		
		return listMethylation;
	}
	
}
