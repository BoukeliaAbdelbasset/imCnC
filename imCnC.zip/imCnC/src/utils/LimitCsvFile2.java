package utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;


public class LimitCsvFile2 {
public static void LimitFirstLabels() 
{
	File file = new File(System.getProperty("user.home")+"/DataSet/HistoneBindingFactor.csv");
	File file1 = new File(System.getProperty("user.home")+"/LimitedDataSet/Test/HBN.csv");
	try {
	BufferedReader buff = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
	BufferedWriter wr =  new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file1)));
	
	String str ="";
	int i = 0;

	while((str=buff.readLine())!=null ) 
	{
		if(str.startsWith("0,")) {
			wr.write(str);
			wr.write(System.lineSeparator());
		i++;
		}
		
	}
	i = 0;
	buff = new BufferedReader(new InputStreamReader(new FileInputStream(file)));

	while((str=buff.readLine())!=null) 
	{
		if(str.startsWith("1,")) {
			wr.write(str);
			wr.write(System.lineSeparator());
		i++;
		}
		
	}
	i = 0;
	buff = new BufferedReader(new InputStreamReader(new FileInputStream(file)));

	while((str=buff.readLine())!=null ) 
	{
		if(str.startsWith("2,")) {
			wr.write(str);
			wr.write(System.lineSeparator());
		i++;
		}
		
	}
	i = 0;
	buff = new BufferedReader(new InputStreamReader(new FileInputStream(file)));

	while((str=buff.readLine())!=null) 
	{
		if(str.startsWith("3,")) {
			wr.write(str);
			wr.write(System.lineSeparator());
		i++;
		}
		
	}
	i = 0;
	buff = new BufferedReader(new InputStreamReader(new FileInputStream(file)));

	while((str=buff.readLine())!=null ) 
	{
		if(str.startsWith("4,")) {
			wr.write(str);
			wr.write(System.lineSeparator());
		i++;
		}
		
	}
	i = 0;
	buff = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
	while((str=buff.readLine())!=null) 
	{
		if(str.startsWith("5,")) {
			wr.write(str);
			wr.write(System.lineSeparator());
		i++;
		}
		
	}
	i = 0;
	buff = new BufferedReader(new InputStreamReader(new FileInputStream(file)));

	while((str=buff.readLine())!=null) 
	{
		if(str.startsWith("6,")) {
			wr.write(str);
			wr.write(System.lineSeparator());
		i++;
		}
		
	}
				
	}
	catch(Exception e) {System.out.println(e);}
		
}
public static void main(String[]args) {
	LimitFirstLabels();
}
}
